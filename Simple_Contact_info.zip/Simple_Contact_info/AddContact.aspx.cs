﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace Simple_Contact_info
{
    public partial class About : Page
    {
        DataSet ds = new DataSet();
        SqlConnection con;
        SqlCommand cmd = new SqlCommand();
        SqlParameter sp1 = new SqlParameter();
        SqlParameter sp2 = new SqlParameter();
        SqlParameter sp3 = new SqlParameter();
        SqlParameter sp4 = new SqlParameter();
        SqlParameter sp = new SqlParameter();


        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            
            con = new SqlConnection(@"server=DESKTOP-J1NS0B9\SQLEXPRESS; database= contact_info; Integrated Security=True");
           
            
            cmd = new SqlCommand("SaveContactS", con);
            cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = Nametxtbox.Text;
            cmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = nmbrtxtbox.Text;
            cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = emailtxtbox.Text;
            cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = Addresstxtbox.Text;
            cmd.Parameters.Add("@Photo", SqlDbType.VarChar).Value = Addresstxtbox.Text;
            cmd.Parameters.Add("@Profession", SqlDbType.VarChar).Value = professiontxtbox.Text;
            cmd.Parameters.Add("@dob", SqlDbType.VarChar).Value = dobtxtbox.Text;


            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}